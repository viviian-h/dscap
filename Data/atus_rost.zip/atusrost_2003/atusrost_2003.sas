data atusrost_2003;
 infile 'c:\atusrost_2003.dat'
 dlm=',' firstobs=2 dsd missover lrecl=16384;
 length
  TUCASEID $14
  TULINENO 8
  TURRP 8
  TESEX 8
  TERRP 8
  TEAGE 8
  TXSEX 8
  TXRRP 8
  TXAGE 8
 ;
 input
  TUCASEID
  TULINENO
  TURRP
  TESEX
  TERRP
  TEAGE
  TXSEX
  TXRRP
  TXAGE
 ;
label TEAGE           = "Edited: Age";
label TERRP           = "Edited: How is this person related to you?";
label TESEX           = "Edited: Sex";
label TUCASEID        = "ATUS Case ID (14-digit identifier)";
label TULINENO        = "ATUS Person Line Number";
label TURRP           = "Relationship to ATUS Respondent";
label TXAGE           = "TEAGE: allocation flag";
label TXRRP           = "TERRP: allocation flag";
label TXSEX           = "TESEX: allocation flag";
run;

PROC FORMAT;
value TERRP
-1     = "Blank"
-2     = "Don't Know"
-3     = "Refused"
18     = "Self"
19     = "Self"
20     = "Spouse (Husband/Wife)"
21     = "Unmarried Partner"
22     = "Own Household Child"
23     = "Grandchild"
24     = "Parent (Mother/Father)"
25     = "Brother/Sister"
26     = "Other Related Person (Aunt, Cousin, Nephew)"
27     = "Foster Child"
28     = "Housemate/Roommate"
29     = "Roomer/Boarder"
30     = "Other Nonrelative"
40     = "Own Non-Household Child"
;
value TESEX
-1     = "Blank"
-2     = "Don't Know"
-3     = "Refused"
1      = "Male"
2      = "Female"
;
value TURRP
-1     = "Blank"
-2     = "Don't Know"
-3     = "Refused"
18     = "Self"
19     = "Self"
20     = "Spouse (Husband/Wife)"
21     = "Unmarried Partner"
22     = "Own Household Child"
23     = "Grandchild"
24     = "Parent (Mother/Father)"
25     = "Brother/Sister"
26     = "Other Related Person (Aunt, Cousin, Nephew)"
27     = "Foster Child"
28     = "Housemate/Roommate"
29     = "Roomer/Boarder"
30     = "Other Nonrelative"
40     = "Own Non-Household Child"
;
value TXAGE
-1     = "Blank"
-2     = "Don't Know"
-3     = "Refused"
0      = "Value - No Change"
1      = "Blank - No Change"
2      = "Don`t Know - No Change"
3      = "Refused - No Change"
10     = "Value To Value"
11     = "Blank To Value"
12     = "Don`t Know To Value"
13     = "Refused To Value"
20     = "Value To Longitudinal Value"
21     = "Blank To Longitudinal Value"
22     = "Don`t Know To Longitudinal Value"
23     = "Refused To Longitudinal Value"
30     = "Value To Allocated Longitudinal Value"
31     = "Blank To Allocated Longitudinal Value"
32     = "Don`t Know To Allocated Longitudinal Value"
33     = "Refused To Allocated Longitudinal Value"
40     = "Value To Allocated Value"
41     = "Blank To Allocated Value"
42     = "Don`t Know To Allocated Value"
43     = "Refused To Allocated Value"
50     = "Value To Blank"
52     = "Don`t Know To Blank"
53     = "Refused To Blank"
60     = "Topcoded"
61     = "Topcoded And Allocated"
;
value TXRRP
-1     = "Blank"
-2     = "Don't Know"
-3     = "Refused"
0      = "Value - No Change"
1      = "Blank - No Change"
2      = "Don`t Know - No Change"
3      = "Refused - No Change"
10     = "Value To Value"
11     = "Blank To Value"
12     = "Don`t Know To Value"
13     = "Refused To Value"
20     = "Value To Longitudinal Value"
21     = "Blank To Longitudinal Value"
22     = "Don`t Know To Longitudinal Value"
23     = "Refused To Longitudinal Value"
30     = "Value To Allocated Value Long."
31     = "Blank To Allocated Value Long."
32     = "Don`t Know To Allocated Value Long."
33     = "Refused To Allocated Value Long."
40     = "Value To Allocated Value"
41     = "Blank To Allocated Value"
42     = "Don`t Know To Allocated Value"
43     = "Refused To Allocated Value"
50     = "Value To Blank"
52     = "Don`t Know To Blank"
53     = "Refused To Blank"
;
value TXSEX
-1     = "Blank"
-2     = "Don't Know"
-3     = "Refused"
0      = "Value - No Change"
1      = "Blank - No Change"
2      = "Don`t Know - No Change"
3      = "Refused - No Change"
10     = "Value To Value"
11     = "Blank To Value"
12     = "Don`t Know To Value"
13     = "Refused To Value"
20     = "Value To Longitudinal Value"
21     = "Blank To Longitudinal Value"
22     = "Don`t Know To Longitudinal Value"
23     = "Refused To Longitudinal Value"
30     = "Value To Allocated Value Long."
31     = "Blank To Allocated Value Long."
32     = "Don`t Know To Allocated Value Long."
33     = "Refused To Allocated Value Long."
40     = "Value To Allocated Value"
41     = "Blank To Allocated Value"
42     = "Don`t Know To Allocated Value"
43     = "Refused To Allocated Value"
50     = "Value To Blank"
52     = "Don`t Know To Blank"
53     = "Refused To Blank"
;
run;

proc contents data=atusrost_2003; run;
